package vulnweb.object;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;

public class AccountDAO {
	public static boolean checkLogin(String username, String password) {
		boolean isValid = false;
		
		String driver = "com.mysql.jdbc.Driver";
		String connectionUrl = "jdbc:mysql://localhost:3306/";
		String database = "shoesdb";
		String userid = "root";
		String password_db = "Password@123";
		
		try {
			Class.forName(driver);
			Connection con = DriverManager.getConnection(connectionUrl+database, userid, password_db);
			String sql = "select * from account where username = ? and password = ?";
			
			PreparedStatement pre = con.prepareStatement(sql);
			pre.setString(1, username);
			pre.setString(2, password);
			
			ResultSet rs = pre.executeQuery();
			if(rs.next()) {
				isValid = true;
			}else {
				isValid = false;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return isValid;
	}
}
